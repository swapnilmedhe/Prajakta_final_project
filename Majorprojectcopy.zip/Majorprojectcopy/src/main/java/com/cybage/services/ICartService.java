package com.cybage.services;

import com.cybage.domain.OrderDetails;
import com.cybage.domain.Orders;
import com.cybage.domain.Product;
import com.cybage.domain.User;

public interface ICartService {

	User getUserData(Integer userId);

	Product getSingleProductData(Integer productId);

	boolean checkUserPrevOrderExistsInOrderTable(User u);

	Orders addNewOrder(Orders o);

	Orders getPrevOrderFromOrderTable(User user);

	OrderDetails addOrderDetails(OrderDetails orderDetails);
	
	
	
	

}
