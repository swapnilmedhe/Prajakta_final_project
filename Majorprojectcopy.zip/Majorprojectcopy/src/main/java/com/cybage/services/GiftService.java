package com.cybage.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.domain.Category;
import com.cybage.domain.Giftfor;
import com.cybage.domain.Occasion;
import com.cybage.domain.Product;
import com.cybage.domain.dto.ProductDto;
import com.cybage.repository.CategoryRepository;
import com.cybage.repository.GiftForRepository;
import com.cybage.repository.OccasionRepository;
import com.cybage.repository.ProductRepository;



@Service
public class GiftService  implements IGiftService{
	
	@Autowired 
	CategoryRepository categoryRepository;
	
	@Autowired 
	GiftForRepository giftForRepository;
	
	@Autowired 
	OccasionRepository occasionRepository;
	
	@Autowired
	ProductRepository proRepo;
	
	

	public Giftfor getGiftFor(Integer id) {
		
		return giftForRepository.findBygiftForId(id);
	}

	public Occasion getOccasion(Integer id) {
		
		return occasionRepository.findByoccasionId(id);
	}

	public Category getCategory(Integer id) {
		// TODO Auto-generated method stub
		return categoryRepository.findBycategoryId(id);
	}

	public List<ProductDto> getperfectGiftPage(Category category, Giftfor gf, Occasion oc) {
	
	List<ProductDto> productDtoList =  new ArrayList<>();
	List<Product> productList = proRepo.findByGiftforAndOccasionAndCategory(category,gf,oc);
	productList.forEach( product->{
		
		ProductDto productDto = new ProductDto();
		if(product.isVisibility())
		{
			productDto.setImage_path(product.getImagePath());
			if(( product.getOffer()!= null))
			{
				productDto.setOffer(product.getOffer());
			}
			productDto.setOffer(0);
			productDto.setProduct_id(product.getProductId());
			productDto.setProduct_name(product.getProductName());
			productDto.setDescription(product.getDescription());
			productDto.setPrice((float) product.getPrice());
			productDtoList.add(productDto);
		}
		
	});
	
	return productDtoList; 
	
}
}
