package com.cybage.services;

import java.util.List;

import com.cybage.domain.Supplier;

public interface ISupplierService {
	public String addSupplierFileData(List<Supplier> s);
	
	public List<Supplier> getList();
	
	public Supplier getSingleSupplier(int id);
	
	public void updateApprovedList(List<Supplier> approvedList);

}
