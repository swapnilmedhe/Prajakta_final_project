package com.cybage.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.domain.Feedback;
import com.cybage.domain.Product;
import com.cybage.domain.User;
import com.cybage.domain.dto.ProductDto;
import com.cybage.repository.FeedbackRepository;
import com.cybage.repository.ProductRepository;
import com.cybage.repository.UserRepository;

@Service
public class UserService implements IUserService{
	
	@Autowired 
	UserRepository userRepo;
	
	@Autowired
	ProductRepository proRepo;
	

	@Autowired
	FeedbackRepository feedRepo;
	
	public User userReg(User u)
	{
		
		return userRepo.save(u);
	}
	
	public User validate(String email, String pass) {
		//System.out.println("in user service "+userRepo.findByEmailAddressAndPassword(email, pass));
		return userRepo.findByEmailAddressAndPassword(email, pass);
	}


	public List<ProductDto> getAllProductList() {
		
		List<ProductDto> productDtoList =  new ArrayList<>();
		List<Product> productList = proRepo.findAll();
		productList.forEach( product->{
			
			ProductDto productDto = new ProductDto();
			if(product.isVisibility())
			{
				productDto.setProduct_id(product.getProductId());
				productDto.setProduct_name(product.getProductName());
				productDto.setDescription(product.getDescription());
				productDto.setImage_path(product.getImagePath());
				if(( product.getOffer()!= null))
				{
					productDto.setOffer(product.getOffer());
				}
				productDto.setOffer(30);
				productDto.setPrice((float) product.getPrice());
				productDtoList.add(productDto);
			}	
		});
		return productDtoList; 
		
	}
	
	public  List<ProductDto> getOfferPage()
	{
		
		List<ProductDto> productDtoList =  new ArrayList<>();
		List<Product> productList = proRepo.findAll();
		productList.forEach( product->{
			
			ProductDto productDto = new ProductDto();
			if(product.isVisibility() && ( product.getOffer()!= null))
			{
				productDto.setProduct_id(product.getProductId());
				productDto.setProduct_name(product.getProductName());
				productDto.setDescription(product.getDescription());
				productDto.setPrice((float) product.getPrice());
				productDto.setImage_path(product.getImagePath());
				productDto.setOffer(product.getOffer());
				productDtoList.add(productDto);
			}
			
			
		});
		return productDtoList; 
		
	}

	public Feedback addFeedBack(Feedback f)
	{
		feedRepo.save(f);
		return f;
	}
	
	

}
