package com.cybage.services;

import java.util.List;

import com.cybage.domain.Product;
import com.cybage.domain.dto.CommonResponseDto;
import com.cybage.domain.dto.ProductDto;

public interface IProductService {
	
	/**
	 * 
	 * @param p
	 * @return
	 */
	CommonResponseDto addProduct(List<Product> p);
	public Product getSingleProduct(Integer id);
	public Product setOfferToProduct(Product prod);
	public List<ProductDto> getProductList();
	public Product searchProducts(Integer id);
	public Product editProducts(Product p, Product p1);
	public void softdelete(Long id);
	

}
