package com.cybage.services;

import java.util.List;

import com.cybage.domain.Feedback;
import com.cybage.domain.User;
import com.cybage.domain.dto.ProductDto;

public interface IUserService {
	
	public User userReg(User u);
	public User validate(String email, String pass);
	public List<ProductDto> getAllProductList();
	public  List<ProductDto> getOfferPage();
	public Feedback addFeedBack(Feedback f);

}
