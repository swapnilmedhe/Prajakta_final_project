package com.cybage.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.domain.Product;
import com.cybage.domain.Supplier;
import com.cybage.domain.dto.CommonResponseDto;
import com.cybage.domain.dto.ProductDto;
import com.cybage.repository.ProductRepository;
import com.cybage.util.Constants;

@Service
public class ProductService implements IProductService{
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CommonResponseDto commonResponseDto;
	
	@Override
	public CommonResponseDto addProduct(List<Product> product)
	{
		productRepository.saveAll(product);
		commonResponseDto.setResponseCode(Constants.SUCCESS_CODE);
		commonResponseDto.setResponseMessage(Constants.PRODUCT_ADDED_SUCCESSFUL);
		return commonResponseDto;
	}
	@Override
	public Product getSingleProduct(Integer id) {
		Product product = productRepository.findByproductId(id);	
		return product;
	}
	@Override
	public Product setOfferToProduct(Product prod)
	{
		return productRepository.save(prod);
	}


	//1.get all product list 
	@Override
	public List<ProductDto> getProductList(){
		List<ProductDto> productDtoList =  new ArrayList<>();
		List<Product> productList = productRepository.findAll();
		productList.forEach( product->{
			
			ProductDto productDto = new ProductDto();
			
				productDto.setProduct_id(product.getProductId());
				productDto.setProduct_name(product.getProductName());
				productDto.setDescription(product.getDescription());
				productDto.setImage_path(product.getImagePath());
				if(( product.getOffer()!= null))
				{
					productDto.setOffer(product.getOffer());
				}
				productDto.setOffer(0);
				productDto.setPrice((float) product.getPrice());
				productDto.setQuantity(product.getQuantity());
				productDtoList.add(productDto);
			
			
		});//end of foreach loop
		
		
		return productDtoList; 
	}
	
	//2.search product 
	@Override
	public Product searchProducts(Integer id) {
		Product p = productRepository.findById(id).get();
		return p;
	}
	//2.edit product		new product,old product
	@Override
	public Product editProducts(Product p, Product p1) {
		p1.setProductName(p.getProductName());
		p1.setPrice(p.getPrice());
		p1.setQuantity(p.getQuantity());
		return productRepository.save(p1);
		
		
	}
	//3.soft delete
	@Override
	public void softdelete(Long id) {
		
		productRepository.deleteProduct(id);
		
	}
	
	
}
