package com.cybage.services;

public interface IGiftService {

}
