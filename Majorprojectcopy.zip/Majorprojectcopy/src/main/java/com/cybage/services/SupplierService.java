package com.cybage.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.domain.Supplier;
import com.cybage.repository.SupplierRepository;
/**
 * @author Administrator
 * 1. Uploading excel sheet product details  data to database
 * 2. Get all products details for approving
 *
 */
@Service
public class SupplierService implements ISupplierService {
	@Autowired
	SupplierRepository supRepo;

	@Override
	public String addSupplierFileData(List<Supplier> s) {

		supRepo.saveAll(s);
		return "successfully added";

	}
	@Override
	public List<Supplier> getList() {

		return (List<Supplier>) supRepo.findAll();
	}
	@Override
	public Supplier getSingleSupplier(int id) {
		Supplier s = supRepo.findBysupplierId(id);
		return s;
	}
	@Override
	public void updateApprovedList(List<Supplier> approvedList) {

		supRepo.saveAll(approvedList);
	}

}
