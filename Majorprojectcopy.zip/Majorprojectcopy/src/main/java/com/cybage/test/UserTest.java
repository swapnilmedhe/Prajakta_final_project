	//import static org.junit.Assert.*;
	//
	//import java.net.URISyntaxException;
	//
	//import javax.validation.Valid;
	//
	//import org.apache.tomcat.jni.User;
	//import org.apache.xmlbeans.impl.xb.xsdschema.Public;
	//import org.junit.Test;
	//
	//import com.cybage.controller.UserController;
	//import com.cybage.repository.UserRepository;
	//import com.cybage.services.UserService;
	//
	//import junit.framework.Assert;
	//
	//public class UserTest {
	//	//positive test case
	//	@Test
	//	public void loginUser(){
	//	
	//		User u = new User();
	//		assertNotNull(u);
	//	
	//}
	//	//negative test case
	//	@Test
	//	public void AdminUser(){
	//		User u = new User();
	//		assertNull(u);
	//	}
	//	
	//}
