package com.cybage.util;

public class Constants {
	
	public final static Integer SUCCESS_CODE=0;
	
	public final static String PRODUCT_ADDED_SUCCESSFUL = "Product Added";
	

}
