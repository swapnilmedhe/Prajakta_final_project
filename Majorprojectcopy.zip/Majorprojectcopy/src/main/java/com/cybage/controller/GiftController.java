package com.cybage.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.domain.Category;
import com.cybage.domain.Giftfor;
import com.cybage.domain.Occasion;
import com.cybage.domain.Product;
import com.cybage.domain.Supplier;
import com.cybage.domain.dto.ProductDto;
import com.cybage.services.CartService;
import com.cybage.services.GiftService;
import com.cybage.services.ProductService;
import com.cybage.services.UserService;

@RestController
public class GiftController {
	
	@Autowired 
	ProductService productService;
	
	@Autowired
	UserService uservice;
	
	@Autowired 
	CartService cartService;
	
	@Autowired
	GiftService giftService;
	
	//all gift list page 
	@GetMapping("/giftListPage")
	public List<ProductDto> getAllProductList()
	{
		return uservice.getAllProductList();
	}
	
	
	//finding perfect gift page
	@PostMapping("/perfectGiftPage")
	public List<ProductDto> getperfectGiftPage(@RequestBody String sid)
	{
		List<Integer> numlist=new ArrayList();//number list
		 
		//convert string array into integer
		System.out.println("sid: "+sid);
		String strNew = sid.substring(1, sid.length()-1);
		String array1[]= strNew.split(",");	
		for (String temp: array1){
		      System.out.println(temp);
		      numlist.add(Integer.parseInt(temp));  
		}
		
		Giftfor gf = giftService.getGiftFor(numlist.get(0)); 
		Occasion oc = giftService.getOccasion(numlist.get(1));
		Category category = giftService.getCategory(numlist.get(2));
		
		List<ProductDto> productDtoList = giftService.getperfectGiftPage(category,gf,oc);
		return productDtoList;
		
	}

	
	
	

}
