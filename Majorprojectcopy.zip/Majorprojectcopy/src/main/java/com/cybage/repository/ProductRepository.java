package com.cybage.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cybage.domain.Category;
import com.cybage.domain.Giftfor;
import com.cybage.domain.Occasion;


import com.cybage.domain.Product;
public interface ProductRepository extends JpaRepository<Product, Integer>{
	

	public List<Product> findAll();
	
	public Product findByproductId(Integer id);
	
	@Transactional
	@Query(value = "Select * from Product prod where prod.category_id  = :category OR prod.giftfor_id = :gf OR prod.occasion_id  = :oc", nativeQuery = true)
	public List<Product> findByGiftforAndOccasionAndCategory(@Param("category")Category category, @Param("gf") Giftfor gf, @Param("oc")Occasion oc);

	 @Modifying
	 @Transactional
	 @Query(value ="UPDATE Product p SET p.visibility = 0 WHERE p.product_id = :id", nativeQuery=true)
	  public void deleteProduct(@Param("id") Long pid);
	 


}
