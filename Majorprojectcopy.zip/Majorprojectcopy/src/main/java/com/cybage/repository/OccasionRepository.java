package com.cybage.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cybage.domain.Category;
import com.cybage.domain.Occasion;

public interface OccasionRepository extends JpaRepository<Occasion, Integer> {
	
	public Occasion findByoccasionId(Integer Id);

}
