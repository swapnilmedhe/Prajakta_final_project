package com.cybage.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cybage.domain.Orders;
import com.cybage.domain.User;

public interface OrdersRepository  extends JpaRepository<Orders, Integer>{
	@Transactional
	@Query(value = "Select * from Orders o where o.user_id = :u", nativeQuery = true)
	Orders findByUser(@Param("u") User u);

}
