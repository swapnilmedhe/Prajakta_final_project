package com.cybage.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cybage.domain.Giftfor;
import com.cybage.domain.Occasion;


public interface GiftForRepository extends JpaRepository<Giftfor, Integer>{
	
	public Giftfor findBygiftForId(Integer Id);
}
