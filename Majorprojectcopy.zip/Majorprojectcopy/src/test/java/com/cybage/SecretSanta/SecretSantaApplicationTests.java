package com.cybage.SecretSanta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecretSantaApplicationTests {

	@Test
	void contextLoads() {
	}

}
